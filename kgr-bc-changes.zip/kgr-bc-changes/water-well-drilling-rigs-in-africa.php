<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

<meta name="description" content="Water well drilling rigs in africa. Kgr rigs keeping in mind the needs and concerns of our client's specifications, we designed the drill rigs. Call us" />
<link rel="canonical" href="https://www.kgrrigs.com/water-well-drilling-rigs-in-africa.php" />

<title>Water Well Drilling Rigs in Africa | Kgr Rigs</title>

<?php include_once("seo-tags.php"); ?>

<!-- favicon icon -->
<link rel="shortcut icon" href="images/kgr/faveicon.png" />
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="css/animate.css" rel="stylesheet" type="text/css" />
<link href="css/fontawesome-all.css" rel="stylesheet" type="text/css" />
<link href="css/themify-icons.css" rel="stylesheet" type="text/css" />
<link href="css/audioplayer/plyr.css" rel="stylesheet" type="text/css" />
<link href="css/magnific-popup/magnific-popup.css" rel="stylesheet" type="text/css" />
<link href="css/owl-carousel/owl.carousel.css" rel="stylesheet" type="text/css" />
<link href="css/base.css" rel="stylesheet" type="text/css" />
<link href="css/shortcodes.css" rel="stylesheet" type="text/css" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="css/responsive.css" rel="stylesheet" type="text/css" />
<link href="css/theme-color/theme-orange.css" data-style="styles" rel="stylesheet">
<!-- inject css end -->
<!-- Google Tag Manager -->
<!--<script>-->
<!--(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':-->
<!--new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],-->
<!--j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=-->
<!--'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);-->
<!--})(window,document,'script','dataLayer','GTM-NKC48FM');-->
<!--</script>-->
<!-- End Google Tag Manager -->
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-N3BMFQ9');</script>
<!-- End Google Tag Manager -->

</head>

<body>
    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N3BMFQ9"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<!-- Google Tag Manager (noscript) -->
<!--<noscript>-->
<!--    <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NKC48FM"-->
<!--height="0" width="0" style="display:none;visibility:hidden"></iframe>-->
<!--</noscript>-->
<!-- End Google Tag Manager (noscript) -->
<!-- page wrapper start -->

<div class="page-wrapper">

<!--header start-->
<?php include_once("header.php"); ?>
<!--header end-->

<!--page title start-->
<section class="page-title o-hidden text-center parallaxie" data-overlay="5" data-bg-img="images/kgr/16.jpg">
  <div class="container">
    <div class="row">
      <div class="col-lg-8 col-md-12 ml-auto mr-auto">
        <h1 class="title mb-0 phseo"> Water well drilling rigs in Africa </h1>
      </div>
    </div>
    <nav aria-label="breadcrumb" class="page-breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="index.php"><i class="fas fa-home"></i></a>
        </li>
        <li class="breadcrumb-item"><a href="sitemap.php">Sitemap</a>
        </li>
        <li class="breadcrumb-item active" aria-current="page"> Water well drilling rigs in Africa </li>
      </ol>
    </nav>
  </div>
</section>

<!--page title end-->


<!--body content start-->

<div class="page-content">

<!--team start-->

<section class="seo-section grey-bg pattern feuture-bottom" data-bg-img="images/kgr/pattern.png">
  <div class="container">
    <div class="row">

      <div class="col-lg-5 col-md-5">
       <div class="masonry row popup-gallery">
          <div class="grid-sizer"></div>
          <div class="masonry-brick cat3">
            <div class="portfolio-item">
              <img src="images/kgr/crig.jpg" alt="Water well drilling rigs in Africa">
              <div class="portfolio-hover">
                <div class="portfolio-title">
                  <h4> Water well drilling rigs in Africa</h4>
                </div>
                <div class="portfolio-icon">
                  <a class="popup popup-img" href="images/kgr/h22.jpg"> <i class="flaticon-magnifier"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="col-lg-7 col-md-7 md-mt-3">
        <div class="team-description">
          <h2 class="title phd z-index-1 mb-4"> Water well drilling rigs in Africa</h2>
          <p class="lead">The most renowned and performance-driven manufacturer of <b>water well drilling rigs in Africa</b> welcomes you. Backed by three decades of unmatched experience in manufacturing drilling products and associated services, we also come with a deep understanding of Africa’s market dynamics and understanding of its terrains. We specialise in providing high-performing drilling solutions to meet the exact needs of our clients depending on the industry they come from. Be it oil, gas, construction or other sectors, we have something in store for you. Some of the products in our portfolio include <a href=”core-drilling-rig.php”> core drilling rigs</a>, piling rigs,rotary water well drilling rigs, etc. </p>
          <h2 class="title phd z-index-1 mb-4">Well Drilling Rig</h2>
          <p class="lead">Currently, we are present in 25-plus countries and serving over 100 institutions for a wide range of drilling projects. Our is a 20,000 sq. mtr production facility located in Hyderabad equipped with a CNC machine shop and system-controlled sealed quenching heat treatment plant. Each of our <b>well drilling rigs</b> and other drilling equipment is manufactured not only to meet the highest industry standards but also customized according to the specifications of our partners. </p>
          <h2 class="title phd z-index-1 mb-4">Well Drilling Machine</h2>
          <p class="lead">Our manufacturing process is characterized by robust build and extended lifespan. This ensures every <b>well drilling machine</b> we deliver can withstand demanding environments while undergoing operation in the African terrain. We are an ISO 9001:2015 certified company and also abide by a slew of internal quality guidelines. </p>
          <p class="lead">With a strong presence in multiple African countries, we combine international standards of performance with a localized understanding of the region to provide solutions that are innovative, relevant, and will have a lasting impact on communities. It is time to join forces with the most trusted providers of <b>water well drilling rigs in Africa</b> and change the landscape for the better. </p>
          
          <p class="line-h-2 mb-0 md-mt-5 mt-20">See also <a href="water-well-drilling-rigs-in-africa.php">Water Well Drilling Rigs in Africa</a></p>


        </div>
      </div>

      <div class="col-lg-12 col-md-12 md-mt-5">
        <div class="tab style-2">
          <!-- Nav tabs -->
          <nav>
            <!-- <div class="nav nav-tabs" id="nav-tab" role="tablist"> <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#tab1-1" role="tab" aria-selected="true">Specifications</a> -->
            </div>
          </nav>
          <!-- Tab panes -->
          <!--<div class="tab-content" id="nav-tabContent">
            <div role="tabpanel" class="tab-pane fade show active" id="tab1-1">
              <div class="row text-black mt-4">
                <div class="col-sm-12">
                  <p>Drilling depth ranges from 1000 to 2000 ft.</p>
                  <p>Formation or Strata is soft, medium and hard</p>
                  <p>The maximum pressure of operation is 230-kg/sq.cm.</p>
                  <p><strong class="mast">MAST Capacity : </strong> 18 tons to 40 tons</p>
                  <p><strong class="mast">MAST Capacity in terms of Rod Handling : </strong> 20 feet.</p>
                  <p><strong class="mast">MAST height : </strong> 9 mts.</p>
                  <p><strong class="mast">Pull up Speed : </strong> 20 mts/min to 42 mts/min.</p>
                  <p><strong class="mast">Pull down Speed : </strong> 30-50 mts/min.</p>
                  
                  <p class="line-h-2 mb-0">In the drilling rig industry, it’s our commitment to bring on the best in our products. Hence, we stand as the refined <strong>DTH drilling rig manufacturers</strong>.</p>-->


              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    </div>
  </div>
</section>

</div>
</div>
<!--page wrapper end-->

<!--footer start-->

<!--footer end--> 

<!-- inject js start -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.appear.js"></script> 
<script src="js/modernizr.js"></script> 
<script src="js/menu/jquery.smartmenus.js"></script>
<script src="js/audioplayer/plyr.min.js"></script>
<script src="js/magnific-popup/jquery.magnific-popup.min.js"></script> 
<script src="js/owl-carousel/owl.carousel.min.js"></script> 
<script src="js/parallax/parallaxie.min.js"></script>
<script src="js/counter/counter.js"></script> 
<script src="js/countdown/jquery.countdown.min.js"></script> 
<script src="js/isotope/isotope.pkgd.min.js"></script> 
<script src="js/theme-script.js"></script>
<?php include_once("footer.php"); ?>
</body>
</html>
