<html>
<head>
    <meta http-equiv="Content-Security-Policy" content="default-src *; style-src 'self' *.livserv.in http://* 'unsafe-inline'; script-src 'self' *.livserv.in 'unsafe-inline' 'unsafe-eval'" />
    <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NKC48FM');</script>
<!-- End Google Tag Manager -->
</head>
<body>
    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NKC48FM"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<script src="http://cwc.livserv.in/chat.js?lid=18950"></script>
<script src="http://cw1.livserv.in?did=18950&amp;pid=1"></script>
</body>
</html>
