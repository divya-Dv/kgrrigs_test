<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

<meta name="description" content="Water well drilling rig manufacturers. Kgr Rigs has Value-based services for value-driven projects. We are in this field for over the past two decades" />
<link rel="canonical" href="https://www.kgrrigs.com/water-well-drilling-rig-manufacturers.php" />

<title>Water Well Drilling Rig Manufacturers | Kgr rigs</title>

<?php include_once("seo-tags.php"); ?>

<!-- favicon icon -->
<link rel="shortcut icon" href="images/kgr/faveicon.png" />
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="css/animate.css" rel="stylesheet" type="text/css" />
<link href="css/fontawesome-all.css" rel="stylesheet" type="text/css" />
<link href="css/themify-icons.css" rel="stylesheet" type="text/css" />
<link href="css/audioplayer/plyr.css" rel="stylesheet" type="text/css" />
<link href="css/magnific-popup/magnific-popup.css" rel="stylesheet" type="text/css" />
<link href="css/owl-carousel/owl.carousel.css" rel="stylesheet" type="text/css" />
<link href="css/base.css" rel="stylesheet" type="text/css" />
<link href="css/shortcodes.css" rel="stylesheet" type="text/css" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="css/responsive.css" rel="stylesheet" type="text/css" />
<link href="css/theme-color/theme-orange.css" data-style="styles" rel="stylesheet">
<!-- inject css end -->
<!-- Google Tag Manager -->
<!--<script>-->
<!--(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':-->
<!--new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],-->
<!--j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=-->
<!--'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);-->
<!--})(window,document,'script','dataLayer','GTM-NKC48FM');-->
<!--</script>-->
<!-- End Google Tag Manager -->
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-N3BMFQ9');</script>
<!-- End Google Tag Manager -->

</head>

<body>
    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N3BMFQ9"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<!-- Google Tag Manager (noscript) -->
<!--<noscript>-->
<!--    <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NKC48FM"-->
<!--height="0" width="0" style="display:none;visibility:hidden"></iframe>-->
<!--</noscript>-->
<!-- End Google Tag Manager (noscript) -->
<!-- page wrapper start -->

<div class="page-wrapper">

<!--header start-->
<?php include_once("header.php"); ?>
<!--header end-->

<!--page title start-->
<section class="page-title o-hidden text-center parallaxie" data-overlay="5" data-bg-img="images/kgr/17.jpg">
  <div class="container">
    <div class="row">
      <div class="col-lg-8 col-md-12 ml-auto mr-auto">
        <h1 class="title mb-0 phseo">Water Well Drilling <span>Rig Manufacturers</span></h1>
      </div>
    </div>
    <nav aria-label="breadcrumb" class="page-breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="index.php"><i class="fas fa-home"></i></a>
        </li>
        <li class="breadcrumb-item"><a href="sitemap.php">Sitemap</a>
        </li>
        <li class="breadcrumb-item active" aria-current="page">Water Well Drilling Rig Manufacturers</li>
      </ol>
    </nav>
  </div>
</section>

<!--page title end-->


<!--body content start-->

<div class="page-content">

<!--team start-->

<section class="seo-section grey-bg pattern feuture-bottom" data-bg-img="images/kgr/pattern.png">
  <div class="container">
    <div class="row">

      <div class="col-lg-5 col-md-5">
       <div class="masonry row popup-gallery">
          <div class="grid-sizer"></div>
          <div class="masonry-brick cat3">
            <div class="portfolio-item">
              <img src="images/kgr/h11.jpg" alt="WATER WELL DRILLING RIG MANUFACTURERS">
              <div class="portfolio-hover">
                <div class="portfolio-title">
                  <h4>Water Well Drilling Rig Manufacturers</h4>
                </div>
                <div class="portfolio-icon">
                  <a class="popup popup-img" href="images/kgr/h11.jpg"> <i class="flaticon-magnifier"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="col-lg-7 col-md-7 md-mt-3">
        <div class="team-description">
          <h2 class="title phd z-index-1 mb-4">Water Well Drilling <span>Rig</span></h2>
          
          <p class="lead">Though water well drilling is challenging, it’s never impossible for the technology experts. The excellence being in the core of excites us to work by keeping more efforts. Regarded as absolutely best <strong>water well drilling rig manufacturers</strong>, we have been exceptional in the field for over the past two decades. The successful journey we are making is because of our deliverables to various industries for various operations.</p>

          <p class="lead">While manufacturing the drilling machines, it’s always crucial to maintaining the defined diameter of the drilling rig.</p>
        </div>
      </div>

      <div class="col-lg-12 col-md-12 md-mt-5">
        <div class="tab style-2">
          <!-- Nav tabs -->
          <nav>
            <div class="nav nav-tabs" id="nav-tab" role="tablist"> <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#tab1-1" role="tab" aria-selected="true">Water well Drilling</a>
            </div>
          </nav>
          <!-- Tab panes -->
          <div class="tab-content" id="nav-tabContent">
            <div role="tabpanel" class="tab-pane fade show active" id="tab1-1">
              <div class="row text-black mt-4">
                <div class="col-sm-12">
                  <p>In water well drilling, DTHR 1000/1500/2000 is preferred</p>
                  <p>The drilling depth varies which extends to 2000 ft starting from 1000 ft</p>
                  <p>The maximum pressure of operation varies from 210 kg/sq.cm to 240 kg/sq.cm.</p>
                  <p>The capacity of the hydraulic oil tank is of about 800 lts.</p>
                  <p>With rotation speed up to 100, it has rotary head torque up to 490 Kgm</p>
                  
                  <p class="line-h-2 mb-0">The best <strong>water well drilling rig manufacturers</strong> are here - KGR. Value based services for value-driven projects. </p>

                  <p class="line-h-2 mb-0 md-mt-5 mt-20">See also <a href="lm100-mining-equipment.php">LM100 Mining Equipment</a></p>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    </div>
  </div>
</section>

</div>
</div>
<!--page wrapper end-->

<!--footer start-->

<!--footer end--> 

<!-- inject js start -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.appear.js"></script> 
<script src="js/modernizr.js"></script> 
<script src="js/menu/jquery.smartmenus.js"></script>
<script src="js/audioplayer/plyr.min.js"></script>
<script src="js/magnific-popup/jquery.magnific-popup.min.js"></script> 
<script src="js/owl-carousel/owl.carousel.min.js"></script> 
<script src="js/parallax/parallaxie.min.js"></script>
<script src="js/counter/counter.js"></script> 
<script src="js/countdown/jquery.countdown.min.js"></script> 
<script src="js/isotope/isotope.pkgd.min.js"></script> 
<script src="js/theme-script.js"></script>
<?php include_once("footer.php"); ?>
</body>
</html>
