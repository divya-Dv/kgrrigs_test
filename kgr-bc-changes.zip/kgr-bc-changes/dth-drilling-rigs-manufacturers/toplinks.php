<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- Fav Icon -->
<link rel="icon" href="img/fav-icon.png" type="image/x-icon">



<link href="assets/css/bootstrap.css" rel="stylesheet">



<link href="assets/css/color.css?v=<? echo time() ?>" rel="stylesheet">
<link href="assets/css/style.css?v=<? echo time() ?>" rel="stylesheet">
<link href="assets/css/responsive.css?v=<? echo time() ?>" rel="stylesheet">


<script src="https://www.google.com/recaptcha/api.js?render=6LceZ8MbAAAAAH4BFsxP87_cyknqnHhsCXyUMS3V"></script>

<script>
function c_validation(){
if(grecaptcha.getResponse() == ""){alert("check roboto");return false}};
</script>

<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-WH8LJJKS');</script>
<!-- End Google Tag Manager -->
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-78RLMVHS4T"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-78RLMVHS4T');
</script>
<style>
    @media (max-width: 786px){
.mobile-iso{
display:none;
}
.mobile-trans{
    z-index:0;
    left: -78px;
    position: relative;
}
.menu-area .mobile-nav-toggler{
    position: relative;
         z-index:999;
        left: 55%;
}
}
</style>
