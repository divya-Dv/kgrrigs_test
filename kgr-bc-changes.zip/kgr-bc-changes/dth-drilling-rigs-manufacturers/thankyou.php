<!DOCTYPE html>
<html lang="en">
<head>
<?php include 'toplinks.php'; ?>
<title>KGR Rigs LP</title>
</head>
<!-- page wrapper -->
<body>
<?php include 'header.php'; ?>
       <!-- page-title -->
        <section class="page-title centred">
            <div class="bg-layer" style="background-image: url(img/thankyou.jpg);"></div>
            <div class="line-box">
                <div class="line-1"></div>
                <div class="line-2"></div>
            </div>
            <div class="auto-container">
                <div class="content-box">
                    <h1>Thank You</h1>
                    <ul class="bread-crumb clearfix">
                        <li><a href="index.php">Home</a></li>
                        <!--<li>About</li>-->
                        <li>Thank You</li>
                    </ul>
                </div>
            </div>
        </section>
        <!-- page-title end -->


        <!-- project-details -->
        <section class="project-details">
            <div class="auto-container">
                <div class="category-box">
                    <div class="row">
                        <div class="col-md-3"> <h1 class="align-center">Thank You</h1></div>
                        <div class="col-md-9">
                            <p>Our team  will be in touch with you shortly. In the meantime, please feel free to explore our website and learn more about our services.</p>
                             <div style="margin-top:30px;">
  <a href="index.php" style="background-image: linear-gradient(to top, #035a42 0%, #24a7f1 100%);
    padding: 10px 15px;
    margin-top: 10px;
    cursor: pointer;
    z-index: 9999;
    
    text-decoration: none;
    color: white;"><i class="fa-solid fa-arrow"></i> Back to Home</a>  
  
   

</div>
                        </div>
                    </div>
                   
              
                </div>
                
            </div>
        </section>
        <!-- project-details end -->
  

<?php include 'footer.php'; ?>
<?php include 'bottomlinks.php'; ?>
</body>
</html>
