<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="keywords" content="HTML5 Template" />
<meta name="description" content="HTML5 Template" />
<meta name="author" content="www.themeht.com" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<title>KGR Rigs</title>

<!-- favicon icon -->
<link rel="shortcut icon" href="images/kgr/faveicon.png" />

<!-- inject css start -->

<!--== bootstrap -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />

<!--== animate -->
<link href="css/animate.css" rel="stylesheet" type="text/css" />

<!--== fontawesome -->
<link href="css/fontawesome-all.css" rel="stylesheet" type="text/css" />

<!--== themify-icons -->
<link href="css/themify-icons.css" rel="stylesheet" type="text/css" />

<!--== audioplayer -->
<link href="css/audioplayer/plyr.css" rel="stylesheet" type="text/css" />

<!--== magnific-popup -->
<link href="css/magnific-popup/magnific-popup.css" rel="stylesheet" type="text/css" />

<!--== owl-carousel -->
<link href="css/owl-carousel/owl.carousel.css" rel="stylesheet" type="text/css" />

<!--== base -->
<link href="css/base.css" rel="stylesheet" type="text/css" />

<!--== shortcodes -->
<link href="css/shortcodes.css" rel="stylesheet" type="text/css" />

<!--== default-theme -->
<link href="css/style.css" rel="stylesheet" type="text/css" />

<!--== responsive -->
<link href="css/responsive.css" rel="stylesheet" type="text/css" />

<!-- inject css end -->
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NKC48FM');</script>
<!-- End Google Tag Manager -->
</head>

<body>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NKC48FM"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<!-- page wrapper start -->

<div class="page-wrapper">

<!-- preloader start -->

<div id="ht-preloader">
  <div class="loader clear-loader"><img src="images/loader.gif" alt="Core Drilling Rigs"></div>
</div>

<!-- preloader end -->


<!--header start-->

<header id="site-header" class="header">
  <div class="top-bar">
    <div class="container">
      <div class="row align-items-center">
        <div class="col-md-4">
          <div class="topbar-link text-left">
            <ul class="list-inline">
              <li class="list-inline-item"><a href="mailto:themeht23@gmail.com"><i class="far fa-envelope-open"></i>themeht23@gmail.com</a>
              </li>
              <li class="list-inline-item">
                <a href="tel:+912345678900"> <i class="fas fa-mobile-alt"></i>+91-234-567-8900</a>
              </li>
            </ul>
          </div>
        </div>
        <div class="col-md-4 col-sm-6 text-center">
          <div class="search-box">
            <form action="http://themeht.com/misto/html/ltr/contact.html" method="post" class="form-inline my-2 my-lg-0">
              <input class="form-control" required="" type="search" placeholder="Search">
              <button class="btn" type="submit"><i class="fas fa-search"></i>
              </button>
            </form>
          </div>
        </div>
        <div class="col-md-4 col-sm-6 text-right">
          <div class="social-icons social-hover top-social-list text-right">
            <ul class="list-inline">
              <li class="social-facebook"><a href="#"><i class="fab fa-facebook-f"></i></a>
              </li>
              <li class="social-gplus"><a href="#"><i class="fab fa-google-plus-g"></i></a>
              </li>
              <li class="social-twitter"><a href="#"><i class="fab fa-twitter"></i></a>
              </li>
              <li class="social-linkedin"><a href="#"><i class="fab fa-linkedin-in"></i></a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div id="header-wrap">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <!-- Navbar -->
          <nav class="navbar navbar-expand-lg">
            <a class="navbar-brand logo" href="index.html">
              <img id="logo-img" class="img-center" src="images/kgr/logo.png" alt="Core Drilling Rigs">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
              <!-- Left nav -->
              <ul id="main-menu" class="nav navbar-nav ml-auto">
                <li class="nav-item"> <a class="nav-link active" href="#"><span class="menu-label">Home</span></a>
                  <ul>
                    <li><a href="index.html">Home 1</a>
                    </li>
                    <li><a href="index-2.html">Home 2</a>
                    </li>
                    <li><a href="index-3.html">Home 3</a>
                    </li>
                    <li><a href="index-4.html">Home 4</a>
                    </li>
                    <li><a href="index-5.html">Home 5</a>
                    </li>
                  </ul>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#"> <span class="menu-label">Pages</span>
                  </a>
                  <ul>
                    <li><a href="about-us.html">About Us</a>
                    </li>
                    <li><a href="faq.html">Faq</a>
                    </li>
                    <li><a href="team-single.html">Team Details</a>
                    </li>
                    <li><a href="coming-soon.html">Coming Soon</a>
                    </li>
                    <li><a href="error-page.html">Error 404</a>
                    </li>
                  </ul>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#"> <span class="menu-label">Solutions</span>
                  </a>
                  <ul>
                    <li><a href="chemical-research.html">Chemical Research</a>
                    </li>
                    <li><a href="energy-%26-power-engineering.html">Energy & Power Engineering</a>
                    </li>
                    <li><a href="petroleum-and-gas.html">Petroleum and Gas</a>
                    </li>
                    <li><a href="agriculture-engineering.html">Agriculture Engineering</a>
                    </li>
                    <li><a href="mechanical-engineering.html">Mechanical Engineering</a>
                    </li>
                    <li><a href="civil-engineering.html">Civil Engineering</a>
                    </li>
                  </ul>
                </li>
                <li class="nav-item fullwidth">
                  <a class="nav-link" href="#"> <span class="menu-label">Element</span>
                  </a>
                  <ul class="grid-12">
                    <li class="container">
                      <div class="row">
                        <div class="col-lg-4 col-md-12">
                          <ul class="nav flex-column">
                            <li> <a href="shortcode-accordions.html">Accordion</a>
                            </li>
                            <li> <a href="shortcode-button.html">Buttons</a>
                            </li>
                            <li> <a href="shortcode-clients.html">Clients</a>
                            </li>
                            <li> <a href="shortcode-counter.html">Counter</a>
                            </li>
                            <li> <a href="shortcode-call-to-action.html">Call to action</a>
                            </li>
                          </ul>
                        </div>
                        <!-- /.col-md-4  -->
                        <div class="col-lg-4 col-md-12">
                          <ul class="nav flex-column">
                            <li> <a href="shortcode-featured-box.html">Featured Box</a>
                            </li>
                            <li> <a href="shortcode-tab.html">Tabs</a>
                            </li>
                            <li> <a href="shortcode-blog-post.html">Post Style</a>
                            </li>
                            <li> <a href="shortcode-pricing.html">Pricing tables</a>
                            </li>
                            <li> <a href="shortcode-progress-bar.html">Progress Bar</a>
                            </li>
                          </ul>
                        </div>
                        <!-- /.col-md-4  -->
                        <div class="col-lg-4 col-md-12">
                          <ul class="nav flex-column">
                            <li> <a href="shortcode-social-icon.html">Social icon</a>
                            </li>
                            <li> <a href="shortcode-testimonials.html">Testimonials</a>
                            </li>
                            <li> <a href="shortcode-team.html">Team</a>
                            </li>
                            <li> <a href="shortcode-heading.html">Heading Style</a>
                            </li>
                            <li> <a href="shortcode-typography.html">Typography</a>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </li>
                    <!--  /.container  -->
                  </ul>
                </li>
                <li class="nav-item"> <a class="nav-link" href="#"><span class="menu-label">Blog</span></a>
                  <ul>
                    <li> <a href="#">Blog Classic</a>
                      <ul>
                        <li><a href="blog-left-sidebar.html">Left Sidebar</a>
                        </li>
                        <li><a href="blog-right-sidebar.html">Right Sidebar</a>
                        </li>
                        <li><a href="blog-fullwidth.html">Fullwidth</a>
                        </li>
                      </ul>
                    </li>
                    <li> <a href="#">Blog Grid</a>
                      <ul>
                        <li><a href="blog-grid-2.html">Grid 2</a>
                        </li>
                        <li><a href="blog-grid-3.html">Grid 3</a>
                        </li>
                      </ul>
                    </li>
                    <li> <a href="#">Blog Masonary</a>
                      <ul>
                        <li><a href="blog-masonry-grid-2.html">Grid 2</a>
                        </li>
                        <li><a href="blog-masonry-grid-3.html">Grid 3</a>
                        </li>
                        <li><a href="blog-masonry-fullwidth.html">Fullwidth</a>
                        </li>
                      </ul>
                    </li>
                    <li> <a href="#">Blog Single</a>
                      <ul>
                        <li><a href="blog-details-left-sidebar.html">Left Sidebar</a>
                        </li>
                        <li><a href="blog-details-right-sidebar.html">Right Sidebar</a>
                        </li>
                        <li><a href="blog-details-fullwidth.html">Fullwidth</a>
                        </li>
                      </ul>
                    </li>
                  </ul>
                </li>
                <li class="nav-item"> <a class="nav-link" href="#"><span class="menu-label">Project</span></a>
                  <ul>
                    <li> <a href="#">Project Grid</a>
                      <ul>
                        <li><a href="project-grid-2.html">Grid 2</a>
                        </li>
                        <li><a href="project-grid-3.html">Grid 3</a>
                        </li>
                        <li><a href="project-grid-4.html">Grid 4</a>
                        </li>
                      </ul>
                    </li>
                    <li> <a href="#">Project Masonry</a>
                      <ul>
                        <li><a href="project-masonary-grid-2.html">Grid 2</a>
                        </li>
                        <li><a href="project-masonary-grid-3.html">Grid 3</a>
                        </li>
                        <li><a href="project-masonary-grid-4.html">Grid 4</a>
                        </li>
                        <li><a href="project-masonary-full-width.html">FullWidth</a>
                        </li>
                      </ul>
                    </li>
                    <li> <a href="project-details.html">Project Details</a>
                    </li>
                  </ul>
                </li>
                <li class="nav-item"> <a class="nav-link" href="#"><span class="menu-label">Contact</span></a>
                  <ul>
                    <li><a href="contact-1.html">Contact 1</a>
                    </li>
                    <li><a href="contact-2.html">Contact 2</a>
                    </li>
                    <li><a href="contact-3.html">Contact 3</a>
                    </li>
                  </ul>
                </li>
              </ul>
            </div>
          </nav>
        </div>
      </div>
    </div>
  </div>
</header>

<!--header end-->


<!--hero section start-->

<section class="banner p-0 pos-r fullscreen-banner text-center">
  <div class="banner-slider owl-carousel no-pb" data-dots="false" data-nav="true">
    <div class="item" data-bg-img="images/kgr/1.jpeg" data-overlay="6">
      <div class="align-center">
        <div class="container">
          <div class="row">
            <div class="col-lg-10 col-md-12 mr-auto ml-auto">
              <div class="box-shadow px-5 xs-px-1 py-5 xs-py-2 banner-1 pos-r" data-bg-color="rgba(255,255,255,0.030)">
                <h5 class="text-white mb-3 letter-space-3 animated6">Misto Industrial</h5>
                <h1 class="text-white mb-3 animated8">Experience <span class="text-theme">And</span> High <span class="text-theme">Quality</span> Service</h1> 
                <p class="lead text-white animated5 mb-3">Misto has provide Best Service our amet,
                  <br>consectetur adipisicing elit.</p> <a class="btn btn-theme btn-radius animated7" href="about-us.html">Learn More</a>
                <a class="btn btn-border btn-radius animated6" href="contact-1.html">Contact US</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="item" data-bg-img="images/kgr/2.jpeg" data-overlay="6">
      <div class="align-center">
        <div class="container">
          <div class="row">
            <div class="col-lg-10 col-md-12 mr-auto ml-auto">
              <div class="box-shadow px-5 xs-px-1 py-5 xs-py-2 banner-1 pos-r" data-bg-color="rgba(255,255,255,0.030)">
                <h5 class="text-white mb-3 letter-space-3 animated6">Our Solution</h5>
                <h1 class="text-white mb-3 animated8">Misto Best <span class="text-theme">Industrial</span> Service <span class="text-theme">Provider</span></h1> 
                <p class="lead text-white animated5 mb-3">Misto has provide Best Service our amet,
                  <br>consectetur adipisicing elit.</p> <a class="btn btn-theme btn-radius animated7" href="about-us.html">Learn More</a>
                <a class="btn btn-border btn-radius animated6" href="contact-1.html">Contact US</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="item" data-bg-img="images/kgr/3.jpeg" data-overlay="6">
      <div class="align-center">
        <div class="container">
          <div class="row">
            <div class="col-lg-10 col-md-12 mr-auto ml-auto">
              <div class="box-shadow px-5 xs-px-1 py-5 xs-py-2 banner-1 pos-r" data-bg-color="rgba(255,255,255,0.030)">
                <h5 class="text-white mb-3 letter-space-3 animated6">What We Do</h5>
                <h1 class="text-white mb-3 animated8">Build <span class="text-theme">Your</span> Industrial <span class="text-theme">Service</span></h1> 
                <p class="lead text-white animated5 mb-3">Misto has provide Best Service our amet,
                  <br>consectetur adipisicing elit.</p> <a class="btn btn-theme btn-radius animated7" href="about-us.html">Learn More</a>
                <a class="btn btn-border btn-radius animated6" href="contact-1.html">Contact US</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!--hero section end-->


<!--body content start-->

<div class="page-content">

<!--about us start-->

<section>
  <div class="container">
    <div class="row text-center">
      <div class="col-lg-8 col-md-10 ml-auto mr-auto">
        <div class="section-title">
          <h2 class="title">about Our <span>Company</span></h2>
          <p class="mb-0">Misto Provide Greate Services for elit. Excepturi vero aliquam id. Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
        </div>
      </div>
    </div>
    <div class="row align-items-center">
      <div class="col-lg-6 col-md-12">
        <div class="row">
          <div class="col-md-6 pr-2">
            <div class="about-img mb-3">
              <img class="img-fluid" src="images/about/02.jpg" alt="Core Drilling Rigs">
            </div>
            <div class="about-img">
              <img class="img-fluid" src="images/about/01.jpg" alt="Core Drilling Rigs">
            </div>
          </div>
          <div class="col-md-6 mt-4 pl-2">
            <div class="about-img mb-3">
              <img class="img-fluid" src="images/about/03.jpg" alt="Core Drilling Rigs">
            </div>
            <div class="about-img">
              <img class="img-fluid" src="images/about/04.jpg" alt="Core Drilling Rigs">
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-6 col-md-12 box-shadow white-bg px-4 py-4 sm-px-3 sm-py-3 xs-py-2 xs-px-2 md-mt-5">
        <h5>What We Do</h5>
        <p class="line-h-3">Misto have facility to produce adipisicing elit. Excepturi vero aliquam id. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi vero minima impedit aliquam id. consectetur adipisicing elit. impedit aliquam id. consectetur adipisicing elit. technologicaly changes and industrial systems.</p>
        <div class="row text-black mt-4">
          <div class="col-sm-6">
            <ul class="list-unstyled">
            <li class="mb-2">- Certified Engineers</li>
            <li class="mb-2">- Design in Quality</li>
            <li>- Best Branding</li>
            </ul>
          </div>
          <div class="col-sm-6 xs-mt-3">
            <ul class="list-unstyled">
            <li class="mb-2">- Expert Engineers</li>
            <li class="mb-2">- Integrity</li>
            <li>- Certified Engineers</li>
          </ul>
          </div>
        </div>
        <div class="row mt-2">
      <div class="col-md-12">
        <div class="ht-progress-bar style-2">
          <h4>Contracting</h4>
          <div class="progress" data-value="90">
            <div class="progress-bar">
              <div class="progress-parcent"><span>90</span>%</div>
            </div>
          </div>
        </div>
        <div class="ht-progress-bar style-2">
          <h4>Plumbing</h4>
          <div class="progress" data-value="65">
            <div class="progress-bar">
              <div class="progress-parcent"><span>65</span>%</div>
            </div>
          </div>
        </div>
      </div>
    </div>
      </div>
    </div>
  </div>
</section>

<!--about us end-->


<!--service start-->

<section class="dark-bg text-center">
  <div class="container">
    <div class="row">
      <div class="col-lg-8 col-md-10 ml-auto mr-auto">
        <div class="section-title">
          <h2 class="title">Our <span> Services</span></h2>
          <p class="mb-0 text-white">Misto Provide Greate Services for elit. Excepturi vero aliquam id. Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="owl-carousel owl-theme" data-items="3" data-md-items="2" data-sm-items="1" data-xs-items="1" data-margin="30">
          <div class="item">
            <div class="service-item">
              <div class="service-images">
                <img class="img-fluid" src="images/service/01.jpg" alt="Core Drilling Rigs">
                <div class="service-icon"> <i class="flaticon-industrial-robot"></i>
                </div>
              </div>
              <div class="service-description">
                <h4>Chemical Research</h4>
                <p>Modern society consumes, consectetur adipisicing elit. Id quae quos cum consequuntur maiores possimus fugiat repellat totam.</p> <a href="chemical-research.html">Read More <i class="fas fa-arrow-right"></i></a>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="service-item">
              <div class="service-images">
                <img class="img-fluid" src="images/service/02.jpg" alt="Core Drilling Rigs">
                <div class="service-icon"> <i class="flaticon-maintenance"></i>
                </div>
              </div>
              <div class="service-description">
                <h4>Energy & Power Engineering</h4>
                <p>Modern society consumes, consectetur adipisicing elit. Id quae quos cum consequuntur maiores possimus fugiat repellat totam.</p> <a href="energy-%26-power-engineering.html">Read More <i class="fas fa-arrow-right"></i></a>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="service-item">
              <div class="service-images">
                <img class="img-fluid" src="images/service/03.jpg" alt="Core Drilling Rigs">
                <div class="service-icon"> <i class="flaticon-fuel-station"></i>
                </div>
              </div>
              <div class="service-description">
                <h4>Petroleum and Gas</h4>
                <p>Modern society consumes, consectetur adipisicing elit. Id quae quos cum consequuntur maiores possimus fugiat repellat totam.</p> <a href="petroleum-and-gas.html">Read More <i class="fas fa-arrow-right"></i></a>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="service-item">
              <div class="service-images">
                <img class="img-fluid" src="images/service/04.jpg" alt="Core Drilling Rigs">
                <div class="service-icon"> <i class="flaticon-growth"></i>
                </div>
              </div>
              <div class="service-description">
                <h4>Agriculture Engineering</h4>
                <p>Modern society consumes, consectetur adipisicing elit. Id quae quos cum consequuntur maiores possimus fugiat repellat totam.</p> <a href="agriculture-engineering.html">Read More <i class="fas fa-arrow-right"></i></a>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="service-item">
              <div class="service-images">
                <img class="img-fluid" src="images/service/05.jpg" alt="Core Drilling Rigs">
                <div class="service-icon"> <i class="flaticon-settings"></i>
                </div>
              </div>
              <div class="service-description">
                <h4>Mechanical Engineering</h4>
                <p>Modern society consumes, consectetur adipisicing elit. Id quae quos cum consequuntur maiores possimus fugiat repellat totam.</p> <a href="mechanical-engineering.html">Read More <i class="fas fa-arrow-right"></i></a>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="service-item">
              <div class="service-images">
                <img class="img-fluid" src="images/service/06.jpg" alt="Core Drilling Rigs">
                <div class="service-icon"> <i class="flaticon-worker"></i>
                </div>
              </div>
              <div class="service-description">
                <h4>Civil Engineering</h4>
                <p>Modern society consumes, consectetur adipisicing elit. Id quae quos cum consequuntur maiores possimus fugiat repellat totam.</p> <a href="civil-engineering.html">Read More <i class="fas fa-arrow-right"></i></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!--service end-->


<!--feauture start-->

<section class="grey-bg pattern feuture-bottom white-overlay" data-bg-img="images/pattern/01.png" data-overlay="3">
  <div class="container">
    <div class="row no-gutters align-items-center">
      <div class="col-lg-6 col-md-6 pr-lg-5 md-px-2 text-center">
        <div class="section-title mb-md-0">
          <h2 class="title">Why <span> Choose Us</span></h2>
          <p class="mb-0">Misto have facility to produce adipisicing elit. Excepturi vero aliquam id. Lorem ipsum dolor sit amet, consectetur adipisicing elit, Excepturi vero minima impedit aliquam.</p>          
        </div>
      </div>
      <div class="col-md-6">
        <div class="featured-item bottom-icon">
          <div class="featured-title text-uppercase">
            <h5>Latest Technology</h5>
          </div>
          <div class="featured-desc">
            <p>Lorem ipsum dolor sit amet, consectetur ili adipiscing elit. Donec nec eros eget pellentesque et non erat. Maecenas nibh dolor, males uada et bibendu ma</p>
          </div>
          <div class="featured-icon"> <i class="flaticon-innovation"></i>
          </div> <span><i class="flaticon-innovation"></i></span>
        </div>
      </div>
    </div>
    <div class="row no-gutters">
      <div class="col-lg-3 col-md-6">
        <div class="featured-item bottom-icon">
          <div class="featured-title text-uppercase">
            <h5>Always Connected</h5>
          </div>
          <div class="featured-desc">
            <p>Lorem ipsum dolor sit amet, consectetur ili adipiscing elit. Donec nec eros eget pellentesque et non erat. Maecenas nibh dolor, males uada et bibendu ma</p>
          </div>
          <div class="featured-icon"> <i class="flaticon-chat-bubble"></i>
          </div> <span><i class="flaticon-chat-bubble"></i></span>
        </div>
      </div>
      <div class="col-lg-3 col-md-6">
        <div class="featured-item bottom-icon">
          <div class="featured-title text-uppercase">
            <h5>Expert Team</h5>
          </div>
          <div class="featured-desc">
            <p>Lorem ipsum dolor sit amet, consectetur ili adipiscing elit. Donec nec eros eget pellentesque et non erat. Maecenas nibh dolor, males uada et bibendu ma</p>
          </div>
          <div class="featured-icon"> <i class="flaticon-employee"></i>
          </div> <span><i class="flaticon-employee"></i></span>
        </div>
      </div>
      <div class="col-lg-3 col-md-6">
        <div class="featured-item bottom-icon">
          <div class="featured-title text-uppercase">
            <h5>Easy And Fast</h5>
          </div>
          <div class="featured-desc">
            <p>Lorem ipsum dolor sit amet, consectetur ili adipiscing elit. Donec nec eros eget pellentesque et non erat. Maecenas nibh dolor, males uada et bibendu ma</p>
          </div>
          <div class="featured-icon"> <i class="flaticon-innovation-1"></i>
          </div> <span><i class="flaticon-innovation-1"></i></span>
        </div>
      </div>
      <div class="col-lg-3 col-md-6">
        <div class="featured-item bottom-icon">
          <div class="featured-title text-uppercase">
            <h5>Delivery Time</h5>
          </div>
          <div class="featured-desc">
            <p>Lorem ipsum dolor sit amet, consectetur ili adipiscing elit. Donec nec eros eget pellentesque et non erat. Maecenas nibh dolor, males uada et bibendu ma</p>
          </div>
          <div class="featured-icon"> <i class="flaticon-alarm-clock"></i>
          </div> <span><i class="flaticon-alarm-clock"></i></span>
        </div>
      </div>
    </div>
  </div>
</section>

<!--feauture end-->


<!--project start-->

<section class="o-hidden">
  <div class="container">
    <div class="row text-center">
      <div class="col-lg-8 col-md-10 ml-auto mr-auto">
        <div class="section-title">
          <h2 class="title">Latest <span> Projects</span></h2>
          <p class="mb-0">Misto Provide Greate Services for elit. Excepturi vero aliquam id. Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
        </div>
      </div>
    </div>
    <div class="row text-center">
      <div class="col-md-12">
        <div class="portfolio-filter">
          <button data-filter="" class="is-checked">All</button>
          <button data-filter=".cat1">Mechanical</button>
          <button data-filter=".cat2">Plumbing</button>
          <button data-filter=".cat3">Welding</button>
          <button data-filter=".cat4">Chemical</button>
        </div>
      </div>
    </div>
  </div>
  <div class="container-fluid p-0">
    <div class="row">
      <div class="col-lg-12 col-md-12">
        <div class="masonry row columns-4 no-gutters popup-gallery">
          <div class="grid-sizer"></div>
          <div class="masonry-brick cat3">
            <div class="portfolio-item">
              <img src="images/portfolio/masonry/01.jpg" alt="Core Drilling Rigs">
              <div class="portfolio-hover">
                <div class="portfolio-title"> <span>Welding, Chemical</span>
                  <h4>Project Title</h4>
                </div>
                <div class="portfolio-icon">
                  <a class="popup popup-img" href="images/portfolio/large/01.jpg"> <i class="flaticon-magnifier"></i>
                  </a>
                  <a class="popup portfolio-link" target="_blank" href="portfolio-details.html"> <i class="flaticon-broken-link-1"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
          <div class="masonry-brick cat3">
            <div class="portfolio-item">
              <img src="images/portfolio/masonry/03.jpg" alt="Core Drilling Rigs">
              <div class="portfolio-hover">
                <div class="portfolio-title"> <span>Welding, Chemical</span>
                  <h4>Project Title</h4>
                </div>
                <div class="portfolio-icon">
                  <a class="popup popup-img" href="images/portfolio/large/03.jpg"> <i class="flaticon-magnifier"></i>
                  </a>
                  <a class="popup portfolio-link" target="_blank" href="portfolio-details.html"> <i class="flaticon-broken-link-1"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
          <div class="masonry-brick cat4">
            <div class="portfolio-item">
              <img src="images/portfolio/masonry/02.jpg" alt="Core Drilling Rigs">
              <div class="portfolio-hover">
                <div class="portfolio-title"> <span>Welding, Chemical</span>
                  <h4>Project Title</h4>
                </div>
                <div class="portfolio-icon">
                  <a class="popup popup-img" href="images/portfolio/large/02.jpg"> <i class="flaticon-magnifier"></i>
                  </a>
                  <a class="popup portfolio-link" target="_blank" href="portfolio-details.html"> <i class="flaticon-broken-link-1"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
          <div class="masonry-brick cat2">
            <div class="portfolio-item">
              <img src="images/portfolio/masonry/04.jpg" alt="Core Drilling Rigs">
              <div class="portfolio-hover">
                <div class="portfolio-title"> <span>Welding, Chemical</span>
                  <h4>Project Title</h4>
                </div>
                <div class="portfolio-icon">
                  <a class="popup popup-img" href="images/portfolio/large/04.jpg"> <i class="flaticon-magnifier"></i>
                  </a>
                  <a class="popup portfolio-link" target="_blank" href="portfolio-details.html"> <i class="flaticon-broken-link-1"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
          <div class="masonry-brick cat1">
            <div class="portfolio-item">
              <img src="images/portfolio/masonry/07.jpg" alt="Core Drilling Rigs">
              <div class="portfolio-hover">
                <div class="portfolio-title"> <span>Welding, Chemical</span>
                  <h4>Project Title</h4>
                </div>
                <div class="portfolio-icon">
                  <a class="popup popup-img" href="images/portfolio/large/07.jpg"> <i class="flaticon-magnifier"></i>
                  </a>
                  <a class="popup portfolio-link" target="_blank" href="portfolio-details.html"> <i class="flaticon-broken-link-1"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
          <div class="masonry-brick cat1">
            <div class="portfolio-item">
              <img src="images/portfolio/masonry/08.jpg" alt="Core Drilling Rigs">
              <div class="portfolio-hover">
                <div class="portfolio-title"> <span>Welding, Chemical</span>
                  <h4>Project Title</h4>
                </div>
                <div class="portfolio-icon">
                  <a class="popup popup-img" href="images/portfolio/large/08.jpg"> <i class="flaticon-magnifier"></i>
                  </a>
                  <a class="popup portfolio-link" target="_blank" href="portfolio-details.html"> <i class="flaticon-broken-link-1"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
          <div class="masonry-brick cat3">
            <div class="portfolio-item">
              <img src="images/portfolio/masonry/06.jpg" alt="Core Drilling Rigs">
              <div class="portfolio-hover">
                <div class="portfolio-title"> <span>Welding, Chemical</span>
                  <h4>Project Title</h4>
                </div>
                <div class="portfolio-icon">
                  <a class="popup popup-img" href="images/portfolio/large/06.jpg"> <i class="flaticon-magnifier"></i>
                  </a>
                  <a class="popup portfolio-link" target="_blank" href="portfolio-details.html"> <i class="flaticon-broken-link-1"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
          <div class="masonry-brick cat4">
            <div class="portfolio-item">
              <img src="images/portfolio/masonry/05.jpg" alt="Core Drilling Rigs">
              <div class="portfolio-hover">
                <div class="portfolio-title"> <span>Welding, Chemical</span>
                  <h4>Project Title</h4>
                </div>
                <div class="portfolio-icon">
                  <a class="popup popup-img" href="images/portfolio/large/05.jpg"> <i class="flaticon-magnifier"></i>
                  </a>
                  <a class="popup portfolio-link" target="_blank" href="portfolio-details.html"> <i class="flaticon-broken-link-1"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
          <div class="masonry-brick cat4">
            <div class="portfolio-item">
              <img src="images/portfolio/masonry/09.jpg" alt="Core Drilling Rigs">
              <div class="portfolio-hover">
                <div class="portfolio-title"> <span>Welding, Chemical</span>
                  <h4>Project Title</h4>
                </div>
                <div class="portfolio-icon">
                  <a class="popup popup-img" href="images/portfolio/large/09.jpg"> <i class="flaticon-magnifier"></i>
                  </a>
                  <a class="popup portfolio-link" target="_blank" href="portfolio-details.html"> <i class="flaticon-broken-link-1"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
          <div class="masonry-brick cat1">
            <div class="portfolio-item">
              <img src="images/portfolio/masonry/10.jpg" alt="Core Drilling Rigs">
              <div class="portfolio-hover">
                <div class="portfolio-title"> <span>Welding, Chemical</span>
                  <h4>Project Title</h4>
                </div>
                <div class="portfolio-icon">
                  <a class="popup popup-img" href="images/portfolio/large/10.jpg"> <i class="flaticon-magnifier"></i>
                  </a>
                  <a class="popup portfolio-link" target="_blank" href="portfolio-details.html"> <i class="flaticon-broken-link-1"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!--project end-->


<!--pricing start-->

<section class="pt-0">
  <div class="container">
    <div class="row text-center">
      <div class="col-lg-8 col-md-10 ml-auto mr-auto">
        <div class="section-title">
          <h2 class="title">Choose Best <span> Asset</span></h2>
          <p class="mb-0">Misto Provide Greate Services for elit. Excepturi vero aliquam id. Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-4 col-md-12">
        <div class="price-table">
          <div class="price-header">
            <h4 class="price-title">Starter</h4>
            <div class="price-value">
              <h2>
              <span class="price-dollar">$</span>99
            </h2>
            </div> <span class="price-month">/Month</span>
          </div>
          <div class="price-list text-center">
            <ul class="list-unstyled">
              <li>Free Consultation</li>
              <li>Unlimited Site licenses</li>
              <li>1 Database</li>
              <li>50gb Web Storage</li>
              <li>Html + Css</li>
              <li>24/7 Customer Support</li>
            </ul>
          </div>
          <a class="btn btn-border btn-circle mt-4" href="#"> <span>Buy Now</span>
          </a>
        </div>
      </div>
      <div class="col-lg-4 col-md-12 md-mt-5">
        <div class="price-table">
          <div class="price-header">
            <h4 class="price-title">Personal</h4>
            <div class="price-value">
              <h2>
              <span class="price-dollar">$</span>199
            </h2>
            </div> <span class="price-month">/Month</span>
          </div>
          <div class="price-list text-center">
            <ul class="list-unstyled">
              <li>Free Consultation</li>
              <li>Unlimited Site licenses</li>
              <li>2 Database</li>
              <li>70gb Web Storage</li>
              <li>Html + Css</li>
              <li>24/7 Customer Support</li>
            </ul>
          </div>
          <a class="btn btn-border btn-circle mt-4" href="#"> <span>Buy Now</span>
          </a>
        </div>
      </div>
      <div class="col-lg-4 col-md-12 md-mt-5">
        <div class="price-table">
          <div class="price-header">
            <h4 class="price-title">Professional</h4>
            <div class="price-value">
              <h2>
              <span class="price-dollar">$</span>299
            </h2>
            </div> <span class="price-month">/Month</span>
          </div>
          <div class="price-list text-center">
            <ul class="list-unstyled">
              <li>Free Consultation</li>
              <li>Unlimited Site licenses</li>
              <li>3 Database</li>
              <li>90gb Web Storage</li>
              <li>Html + Css</li>
              <li>24/7 Customer Support</li>
            </ul>
          </div>
          <a class="btn btn-border btn-circle mt-4" href="#"> <span>Buy Now</span>
          </a>
        </div>
      </div>
    </div>
  </div>
</section>

<!--pricing end-->


<!--counter start-->

<section class="grey-bg">
  <div class="container">
    <div class="row">
      <div class="col-lg-3 col-sm-6">
        <div class="counter"> <i class="flaticon-innovation"></i>
          <span class="count-number" data-to="150" data-speed="10000">150</span>
          <label>Projects</label>
        </div>
      </div>
      <div class="col-lg-3 col-sm-6">
        <div class="counter"> <i class="flaticon-pencil"></i>
          <span class="count-number" data-to="175" data-speed="10000">175</span>
          <label>Success Project</label>
        </div>
      </div>
      <div class="col-lg-3 col-sm-6">
        <div class="counter md-mt-3"> <i class="flaticon-coffee-cup"></i>
          <span class="count-number" data-to="344" data-speed="10000">344</span>
          <label>Coffee Cup</label>
        </div>
      </div>
      <div class="col-lg-3 col-sm-6">
        <div class="counter md-mt-3"> <i class="flaticon-employee"></i>
          <span class="count-number" data-to="125" data-speed="10000">125</span>
          <label>Happy Clients</label>
        </div>
      </div>
    </div>
  </div>
</section>

<!--counter end-->


<!--multi section start-->

<section>
  <div class="container">
    <div class="row align-items-center">
      <div class="col-lg-6 col-md-12">
        <div class="owl-carousel owl-theme no-pb xs-text-center" data-dots="false" data-items="3" data-margin="30" data-autoplay="true">
          <div class="item">
            <img class="img-center" src="images/client/03.png" alt="Core Drilling Rigs">
          </div>
          <div class="item">
            <img class="img-center" src="images/client/04.png" alt="Core Drilling Rigs">
          </div>
          <div class="item">
            <img class="img-center" src="images/client/03.png" alt="Core Drilling Rigs">
          </div>
          <div class="item">
            <img class="img-center" src="images/client/04.png" alt="Core Drilling Rigs">
          </div>
        </div>
        <div class="row mt-5">
          <div class="col-sm-12">
            <div class="tab">
              <!-- Nav tabs -->
              <nav>
                <div class="nav nav-tabs" id="nav-tab" role="tablist"> <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#tab1-1" role="tab" aria-selected="true">Our Mission</a>
                  <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#tab1-2" role="tab" aria-selected="false">Our Vission</a>
                </div>
              </nav>
              <!-- Tab panes -->
              <div class="tab-content pl-3 pt-3 pb-0" id="nav-tabContent">
                <div role="tabpanel" class="tab-pane fade show active" id="tab1-1">
                  <p class="mb-0 lead">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever</p>
                  <div class="row text-black mt-4">
                    <div class="col-sm-6">
                      <ul class="list-unstyled">
                      <li class="mb-2">- Certified Engineers</li>
                      <li class="mb-2">- Design in Quality</li>
                      <li>- Best Branding</li>
                    </ul>
                    </div>
                    <div class="col-sm-6 xs-mt-3">
                      <ul class="list-unstyled">
                      <li class="mb-2">- Expert Engineers</li>
                      <li class="mb-2">- Integrity</li>
                      <li>- Certified Engineers</li>
                    </ul>
                    </div>
                  </div>
                </div>
                <div role="tabpanel" class="tab-pane fade" id="tab1-2">
                  <p class="mb-0 lead">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever</p>
                  <div class="row text-black mt-4">
                    <div class="col-sm-6">
                      <h6 class="mb-2">- Certified Engineers</h6>
                      <h6 class="mb-2">- Design in Quality</h6>
                      <h6>- Best Branding</h6>
                    </div>
                    <div class="col-sm-6 xs-mt-3">
                      <h6 class="mb-2">- Expert Engineers</h6>
                      <h6 class="mb-2">- Integrity</h6>
                      <h6>- Certified Engineers</h6>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-6 col-md-12 md-mt-5">
        <div id="accordion" class="accordion style-1">
          <div class="card active">
            <div class="card-header">
              <h6 class="mb-0">
              <a data-toggle="collapse" data-parent="#accordion" href="#collapse1" aria-expanded="true">consectetur adipisicing elit, sed ?</a>
              </h6>
            </div>
            <div id="collapse1" class="collapse show" data-parent="#accordion">
              <div class="card-body">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmodas temporo incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, Duis aute dolor in reprehenderit.</div>
            </div>
          </div>
          <div class="card">
            <div class="card-header">
              <h6 class="mb-0">
              <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">temporo incididunt ut labore et dolore ?</a>
              </h6>
            </div>
            <div id="collapse2" class="collapse" data-parent="#accordion">
              <div class="card-body">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmodas temporo incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, Duis aute dolor in reprehenderit.</div>
            </div>
          </div>
          <div class="card">
            <div class="card-header">
              <h6 class="mb-0">
              <a data-toggle="collapse" data-parent="#accordion" href="#collapse3">quis nostrd exercitation ullamco laboris ?</a>
              </h6>
            </div>
            <div id="collapse3" class="collapse" data-parent="#accordion">
              <div class="card-body">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmodas temporo incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, Duis aute dolor in reprehenderit.</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!--multi section end-->


<!--testimonial start-->

<section class="dark-bg parallaxie" data-bg-img="images/bg/02.jpg" data-overlay="9">
  <div class="container">
    <div class="row text-center">
      <div class="col-md-8 ml-auto mr-auto">
        <div class="section-title">
          <h2 class="title">Our <span> Testimonial</span></h2>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-sm-12">
        <div class="owl-carousel owl-theme" data-items="1" data-autoplay="true">
          <div class="item">
            <div class="testimonial">
              <div class="row">
                <div class="col-lg-10 col-md-12 ml-auto mr-auto">
                  <div class="testimonial-avatar">
                    <div class="testimonial-img">
                      <img class="img-center" src="images/thumbnail/01.png" alt="Core Drilling Rigs">
                    </div>
                  </div>
                  <div class="testimonial-content"> <span><i class="fas fa-quote-left"></i></span>
                    <p>consectetur adipisicing elit. Totam mollitia incidunt vero cupiditate obcaecati iusto tempora unde! Numquam officiis, quae adipisci quam laudantium nulla modi. adipisci quam laudantium nulla modi. Totam mollitia incidunt vero cupiditate obcaecati</p>
                    <div class="testimonial-caption">
                      <h6>John Doe -</h6>
                      <label>Architect</label>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="testimonial">
              <div class="col-lg-10 col-md-12 ml-auto mr-auto">
                <div class="testimonial-avatar">
                  <div class="testimonial-img">
                    <img class="img-center" src="images/thumbnail/02.png" alt="Core Drilling Rigs">
                  </div>
                </div>
                <div class="testimonial-content"> <span><i class="fas fa-quote-left"></i></span>
                  <p>consectetur adipisicing elit. Totam mollitia incidunt vero cupiditate obcaecati iusto tempora unde! Numquam officiis, quae adipisci quam laudantium nulla modi. adipisci quam laudantium nulla modi. Totam mollitia incidunt vero cupiditate obcaecati</p>
                  <div class="testimonial-caption">
                    <h6>Kelly Rain -</h6>
                    <label>Engineers</label>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="testimonial">
              <div class="col-lg-10 col-md-12 ml-auto mr-auto">
                <div class="testimonial-avatar">
                  <div class="testimonial-img">
                    <img class="img-center" src="images/thumbnail/03.png" alt="Core Drilling Rigs">
                  </div>
                </div>
                <div class="testimonial-content"> <span><i class="fas fa-quote-left"></i></span>
                  <p>consectetur adipisicing elit. Totam mollitia incidunt vero cupiditate obcaecati iusto tempora unde! Numquam officiis, quae adipisci quam laudantium nulla modi. adipisci quam laudantium nulla modi. Totam mollitia incidunt vero cupiditate obcaecati</p>
                  <div class="testimonial-caption">
                    <h6>Jamy Lynn -</h6>
                    <label>Manager</label>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!--testimonial end-->


<!--team start-->

<section>
  <div class="container">
    <div class="row text-center">
      <div class="col-lg-8 col-md-10 ml-auto mr-auto">
        <div class="section-title">
          <h2 class="title">Meet With <span> Engineers</span></h2>
          <p class="mb-0">Misto Provide Greate Services for elit. Excepturi vero aliquam id. Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-4 col-md-12">
        <div class="team-member text-center">
          <div class="team-images">
            <img class="img-fluid" src="images/team/01.jpg" alt="Core Drilling Rigs">
            <div class="team-social-icon">
              <ul>
                <li><a href="#"><i class="fab fa-facebook-f"></i></a>
                </li>
                <li><a href="#"><i class="fab fa-twitter"></i></a>
                </li>
                <li><a href="#"><i class="fab fa-google-plus-g"></i></a>
                </li>
                <li><a href="#"><i class="fab fa-linkedin-in"></i></a>
                </li>
              </ul>
            </div>
          </div>
          <div class="team-description">
            <h5><a href="team-single.html">John Maxwell</a></h5>
            <span>Architect</span>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-12 md-mt-5">
        <div class="team-member text-center">
          <div class="team-images">
            <img class="img-fluid" src="images/team/02.jpg" alt="Core Drilling Rigs">
            <div class="team-social-icon">
              <ul>
                <li><a href="#"><i class="fab fa-facebook-f"></i></a>
                </li>
                <li><a href="#"><i class="fab fa-twitter"></i></a>
                </li>
                <li><a href="#"><i class="fab fa-google-plus-g"></i></a>
                </li>
                <li><a href="#"><i class="fab fa-linkedin-in"></i></a>
                </li>
              </ul>
            </div>
          </div>
          <div class="team-description">
            <h5><a href="team-single.html">Matthew Doe</a></h5>
            <span>Mechanical</span>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-12 md-mt-5">
        <div class="team-member text-center">
          <div class="team-images">
            <img class="img-fluid" src="images/team/03.jpg" alt="Core Drilling Rigs">
            <div class="team-social-icon">
              <ul>
                <li><a href="#"><i class="fab fa-facebook-f"></i></a>
                </li>
                <li><a href="#"><i class="fab fa-twitter"></i></a>
                </li>
                <li><a href="#"><i class="fab fa-google-plus-g"></i></a>
                </li>
                <li><a href="#"><i class="fab fa-linkedin-in"></i></a>
                </li>
              </ul>
            </div>
          </div>
          <div class="team-description">
            <h5><a href="team-single.html">Romi Keely</a></h5>
            <span>Manager</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!--team end-->


<!--subscribe start-->

<section class="grey-bg py-5">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-md-8 col-sm-12">
        <h3 class="text-black">Are You Looking Great Solution <span class="text-theme font-weight-bold"> For Your Company?</span></h3>
      </div>
      <div class="col-md-4 col-sm-12 text-md-right sm-mt-3"> <a href="#" class="btn btn-theme"><span>Contact Us</span></a>
      </div>
    </div>
  </div>
</section>

<!--subscribe end-->


<!--blog start-->

<section class="pb-17 sm-pb-8">
  <div class="container">
    <div class="row text-center">
      <div class="col-lg-8 col-md-10 ml-auto mr-auto">
        <div class="section-title">
          <h2 class="title">Latest <span> News</span></h2>
          <p class="mb-0">Latest News For Our Solution Services for elit. Excepturi vero aliquam id. Lorem ipsum dolor amet, consectetur adipisicing elit.</p>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-4 col-md-12">
        <div class="post">
          <div class="post-image">
            <img src="images/blog/01.jpg" alt="Core Drilling Rigs">
            <div class="post-date">23 April, 2019</div>
          </div>
          <div class="post-desc">
            <div class="post-title">
              <h5><a href="blog-details-right-sidebar.html">The engineer of industrial</a></h5>
            </div>
            <p>Cras ultricies ligula sed magna dictum porta, Sed ut perspiciatis unde omnis iste natus error sit voluptat</p>
          </div>
          <div class="post-bottom">
            <div class="post-meta">
              <ul class="list-inline">
                <li>Like</li>
                <li>Comment</li>
              </ul>
            </div> <a class="post-btn" href="blog-details-right-sidebar.html">Read More<i class="ml-2 fas fa-long-arrow-alt-right"></i></a>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-12 md-mt-5">
        <div class="post">
          <div class="post-image">
            <img src="images/blog/02.jpg" alt="Core Drilling Rigs">
            <div class="post-date">23 April, 2019</div>
          </div>
          <div class="post-desc">
            <div class="post-title">
              <h5><a href="blog-details-right-sidebar.html">Management of workflows</a></h5>
            </div>
            <p>Cras ultricies ligula sed magna dictum porta, Sed ut perspiciatis unde omnis iste natus error sit voluptat</p>
          </div>
          <div class="post-bottom">
            <div class="post-meta">
              <ul class="list-inline">
                <li>Like</li>
                <li>Comment</li>
              </ul>
            </div> <a class="post-btn" href="blog-details-right-sidebar.html">Read More<i class="ml-2 fas fa-long-arrow-alt-right"></i></a>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-12 md-mt-5">
        <div class="post">
          <div class="post-image">
            <img src="images/blog/03.jpg" alt="Core Drilling Rigs">
            <div class="post-date">23 April, 2019</div>
          </div>
          <div class="post-desc">
            <div class="post-title">
              <h5><a href="blog-details-right-sidebar.html">industrial profits grow</a></h5>
            </div>
            <p>Cras ultricies ligula sed magna dictum porta, Sed ut perspiciatis unde omnis iste natus error sit voluptat</p>
          </div>
          <div class="post-bottom">
            <div class="post-meta">
              <ul class="list-inline">
                <li>Like</li>
                <li>Comment</li>
              </ul>
            </div> <a class="post-btn" href="blog-details-right-sidebar.html">Read More<i class="ml-2 fas fa-long-arrow-alt-right"></i></a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!--blog end-->


</div>

<!--body content end--> 


<!--footer start-->

<footer class="footer dark-bg pt-10 sm-pt-8 pos-r" data-bg-img="images/bg/09.png" style="background-size: contain; background-repeat: no-repeat;">
  <div class="contact-media">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <ul class="media-icon style-2 list-inline theme-bg">
            <li> <i class="flaticon-paper-plane"></i>
              <span>Address:</span>
              <p class="mb-0">423B, Road Wordwide Country, USA</p>
            </li>
            <li> <i class="flaticon-phone-call"></i>
              <span>Phone:</span>
              <a href="tel:+912345678900">+91-234-567-8900</a>
            </li>
            <li> <i class="flaticon-message"></i>
              <span>Email:</span>
              <a href="mailto:themeht23@gmail.com">themeht23@gmail.com</a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <div class="primary-footer">
    <div class="container">
      <div class="row">
        <div class="col-lg-3 col-md-6">
          <h5>About <span class="text-theme"> Industrial</span></h5>
          <p class="mb-3">Misto Industrial is fully responsible, Performance oriented theme. Build whatever you like with the Misto. Misto is the creative, modern and multipurpose HTML5 Template suitable for Your business.</p> <a class="btn-simple" href="#"><span>Read More <i class="ml-2 fas fa-long-arrow-alt-right"></i></span></a>
        </div>
        <div class="col-lg-3 col-md-6 sm-mt-5 footer-list">
          <h5>Our <span class="text-theme"> Solutions</span></h5>
          <ul class="list-unstyled">
            <li><a href="chemical-research.html"><i class="fas fa-angle-right"></i> Chemical Research</a>
            </li>
            <li><a href="energy-%26-power-engineering.html"><i class="fas fa-angle-right"></i> Energy & Power Enginerring</a>
            </li>
            <li><a href="petroleum-and-gas.html"><i class="fas fa-angle-right"></i> Petroleum and Gas</a>
            </li>
            <li><a href="agriculture-engineering.html"><i class="fas fa-angle-right"></i> Agriculture Engineering</a>
            </li>
            <li><a href="mechanical-engineering.html"><i class="fas fa-angle-right"></i> Mechanical Engineering</a>
            </li>
            <li><a href="civil-engineering.html"><i class="fas fa-angle-right"></i> Civil Engineering</a>
            </li>
          </ul>
        </div>
        <div class="col-lg-3 col-md-6 md-mt-5 widget">
          <h5>Recent <span class="text-theme"> Post</span></h5>
          <div class="recent-post mb-0">
            <ul class="list-unstyled">
              <li class="mb-3">
                <div class="recent-post-thumb">
                  <img class="img-fluid" src="images/blog/blog-thumb/01.jpg" alt="Core Drilling Rigs">
                </div>
                <div class="recent-post-desc"> <a href="#">Misto Industrial is fully responsible</a>
                  <span>April 23, 2019</span>
                </div>
              </li>
              <li>
                <div class="recent-post-thumb">
                  <img class="img-fluid" src="images/blog/blog-thumb/02.jpg" alt="Core Drilling Rigs">
                </div>
                <div class="recent-post-desc"> <a href="#">Whatever you like with the Misto</a>
                  <span>April 23, 2019</span>
                </div>
              </li>
            </ul>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 md-mt-5">
          <h5>Working <span class="text-theme"> hours</span></h5>
          <p>Misto Working Hours amet elit, sed do eiusmod tempor dolore.</p>
          <ul class="list-unstyled working-hours clearfix">
            <li><span>Monday - Friday</span> 10:00 to 6:00</li>
            <li><span>Sunday</span> Closed</li>
          </ul>
          <div class="social-icons social-colored mt-3">
              <ul class="list-inline mb-0">
                <li class="social-facebook"><a href="#"><i class="fab fa-facebook-f" aria-hidden="true"></i></a>
                </li>
                <li class="social-twitter"><a href="#"><i class="fab fa-twitter" aria-hidden="true"></i></a>
                </li>
                <li class="social-gplus"><a href="#"><i class="fab fa-google-plus-g" aria-hidden="true"></i></a>
                </li>
                <li class="social-linkedin"><a href="#"><i class="fab fa-linkedin-in" aria-hidden="true"></i></a>
                </li>
              </ul>
            </div>
        </div>
      </div>
    </div>
  </div>
  <div class="secondary-footer">
    <div class="container">
      <div class="copyright">
        <div class="row align-items-center">
          <div class="col-md-7">
           <span>Copyright 2018 Misto Theme by <a target="_blank" href="www.themeht.html"> ThemeHt </a> | All Rights Reserved</span>
          </div>
          <div class="col-md-5 text-md-right sm-mt-3 footer-list">
            <ul class="list-inline">
              <li><a href="terms-and-conditions.html">Terms & Condition</a></li>
              <li><a href="privacy-policy.html">Privacy Policy</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</footer>

<!--footer end-->


</div>

<!-- page wrapper end -->


<!-- get a quote start -->

<a class="contact-btn" data-toggle="modal" data-target="#myModal">
  <div class="contact-bg">Get a Quote</div>
</a>
<div class="contact-form text-black"> <a class="close-btn text-capitalize text-right"><i class="flaticon-cancel"></i></a>
  <h2 class="title mb-5">Request A <span> Quote </span></h2>
  <form id="queto-form" method="post" action="http://themeht.com/misto/html/ltr/php/contact.php">
    <div class="messages"></div>
    <div class="form-group">
      <input id="form_name1" type="text" name="name" class="form-control" placeholder="Your Name" required="required" data-error="Name is required.">
      <div class="help-block with-errors"></div>
    </div>
    <div class="form-group">
      <input id="form_email1" type="email" name="email" class="form-control" placeholder="Your Email" required="required" data-error="Valid email is required.">
      <div class="help-block with-errors"></div>
    </div>
    <div class="form-group">
      <input id="form_project1" type="text" name="name" class="form-control" placeholder="Project Name" required="required">
    </div>
    <div class="form-group">
      <textarea id="form_message1" name="message" class="form-control" placeholder="Your Message" rows="4" required="required" data-error="Please,leave us a message."></textarea>
      <div class="help-block with-errors"></div>
    </div>
    <button class="btn btn-border btn-radius"><span>Submit</span>
    </button>
  </form>
</div>

<!-- get a quote end -->


<!--back-to-top start-->

<div class="scroll-top"><a class="smoothscroll" href="#top"><i class="fas fa-chevron-up"></i></a></div>

<!--back-to-top end-->

 
<!--== jquery -->
<script src="js/jquery.min.js"></script>

<!--== popper -->
<script src="js/popper.min.js"></script>

<!--== bootstrap -->
<script src="js/bootstrap.min.js"></script>

<!--== appear -->
<script src="js/jquery.appear.js"></script> 

<!--== modernizr -->
<script src="js/modernizr.js"></script> 

<!--== menu --> 
<script src="js/menu/jquery.smartmenus.js"></script>

<!--== audioplayer -->
<script src="js/audioplayer/plyr.min.js"></script>

<!--== magnific-popup -->
<script src="js/magnific-popup/jquery.magnific-popup.min.js"></script> 

<!--== owl-carousel -->
<script src="js/owl-carousel/owl.carousel.min.js"></script> 

<!--== parallax -->
<script src="js/parallax/parallaxie.min.js"></script>

<!--== counter -->
<script src="js/counter/counter.js"></script> 

<!--== countdown -->
<script src="js/countdown/jquery.countdown.min.js"></script> 

<!--== isotope -->
<script src="js/isotope/isotope.pkgd.min.js"></script> 

<!--== contact-form -->
<script src="js/contact-form/contact-form.js"></script>

<!--== particle -->
<script src="js/particle/jquery.particleground.min.js"></script> 

<!--== theme-script -->
<script src="js/theme-script.js"></script>

<!-- inject js end -->

</body>
</html>
